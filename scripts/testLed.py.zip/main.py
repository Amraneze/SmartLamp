import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BOARD)
#import motor
import light

#motor.stop()
#motor.turnLeft()
#motor.turnRight()
#motor.forward()

#for x in range(0, 10):
    #motor.forward()
    #motor.stop()
    #motor.turnLeft()
    #motor.turnRight()
    #motor.forward()


#GPIO.cleanup()

light.turnLightOff()
    
#light.turnLightOff()

GPIO.cleanup()

