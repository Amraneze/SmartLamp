import os
import glob
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BOARD)
import time
import motor
from bluetooth import *

#light1 = 7 #GPIO4
#light2 = 11 #GPIO17
#gpioPin=0

#GPIO.setmode(GPIO.BOARD)
#GPIO.setwarnings(0)
#res = GPIO.setup(light1, GPIO.OUT)
#res = GPIO.setup(light2, GPIO.OUT)

#GPIO.cleanup()

server_sock = BluetoothSocket( RFCOMM )
server_sock.bind(("", PORT_ANY))
server_sock.listen(1)

port = server_sock.getsockname()[1]

print port

uuid = "94f39d29-7d6d-437d-973b-fba39e49d4ee"
advertise_service (server_sock, "WashStServer",
                   service_id = uuid,
                   service_classes = [uuid, SERIAL_PORT_CLASS],
                   profiles = [SERIAL_PORT_PROFILE],)
connected = 0
while True:
    if (connected == 0):
        print "waiting for connection"
        client_sock, client_info = server_sock.accept()
        print "Accepted connection from ", client_info
        connected = 1

    try:
        data = client_sock.recv(1024)
        if len(data) == 0: break
        
        print "received data", data
        if data == '1':
            print "come light2 1"
            motor.forward()
            #GPIO.output(light2, 1)
        elif data =='0':
            print "come light2 0"
            motor.stop()
            #GPIO.output(light2, 0)
        else:
            print "come error"
            
    except IOError:
        print "error"
        connected = 0;
        pass
    except KeyboardInterrupt:
        print "disconnecitng"
        client_sock.close()
        server_sock.close()
        connected = 0
        print "all done"

        break


